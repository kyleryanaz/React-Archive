import React from "react";
import ReactDOM from "react-dom";

class NumberOfStudents extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      enrolledStudents: 25,
      waitlistedStudents: 10,
      toAddEnrolled: 0,
      toAddWaitlisted: 0
    };
  }

  incrementEnrolled() {
    this.setState({
      enrolledStudents: this.state.enrolledStudents + 1
    });
  }

  addEnrolled() {
    this.setState({
      enrolledStudents:
        this.state.enrolledStudents + parseInt(this.state.toAddEnrolled)
    });
  }

  incrementWaitlisted() {
    this.setState({
      waitlistedStudents: this.state.waitlistedStudents + 1
    });
  }

  addWaitlisted() {
    this.setState({
      waitlistedStudents:
        this.state.waitlistedStudents + parseInt(this.state.toAddWaitlisted)
    });
  }

  render() {
    return (
      <div>
        <h1>Enrolled Students: {this.state.enrolledStudents}</h1>
        <button onClick={this.incrementEnrolled.bind(this)}>
          Add 1 Enrolled Student
        </button>

        <input
          type="number"
          onChange={event => {
            this.setState({ toAddEnrolled: event.target.value });
            console.log(this.state.toAddEnrolled);
          }}
          value={this.state.toAddEnrolled}
        />
        <button onClick={this.addEnrolled.bind(this)}>Add Enrolled</button>
        <h1>Waitlisted Students: {this.state.waitlistedStudents}</h1>
        <button onClick={this.incrementWaitlisted.bind(this)}>
          Add 1 Waitlisted Student
        </button>
        <input
          type="number"
          onChange={event => {
            this.setState({ toAddWaitlisted: event.target.value });
            console.log(this.state.toAddWaitlisted);
          }}
          value={this.state.toAddWaitlisted}
        />
        <button onClick={this.addWaitlisted.bind(this)}>Add Waitlisted</button>
      </div>
    );
  }
}

const App = props => {
  return <NumberOfStudents />;
};

ReactDOM.render(<App />, document.getElementById("root"));
