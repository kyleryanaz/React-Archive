import React from 'react';

const UserOutput = props => {
    return (
        <div className="UserOutput">
        <h3>{props.username}</h3>
        <p>I miss Maeby</p>
        <p>Is this a paragraph? :p</p>
        </div>
    );
};

export default UserOutput;