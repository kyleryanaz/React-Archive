import React, { Component } from 'react';
import './App.css';
import UserInput from "./components/UserInput";
import UserOutput from "./components/UserOutput";

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "Wade"
    };

    this.changeUsername = this.changeUsername.bind(this);
    
  }

  changeUsername = e => {
    this.setState({
      username: e.target.value
    });
  }

  render() {
    return (
      <div className="App">
        <h1>App</h1>
        <UserInput
        update={this.changeUsername}
        username={this.state.username}
         />
        <UserOutput username="Kyle" />
        <UserOutput username={this.state.username} />
      </div>
    );
  }
}

export default App;
