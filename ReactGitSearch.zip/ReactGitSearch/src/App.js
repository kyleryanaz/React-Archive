import React, { Component } from 'react';
import {connect} from 'react-redux';

class App extends Component {

  onHandleChange = (e) => {
    let {dispatch} = this.props;
    dispatch({type: 'UPDATE_USERNAME', username: e.target.value})
  }

  onUserSearch = () => {
    let {dispatch} = this.props;
    let {username} = this.props;
    fetch(`https://api.github.com/users/${username}`)
      .then(res => {
        return res.json()
      })
      .then(res => {
        dispatch({type: 'UPDATE_USERPROFILE', userprofile: res})
      })
  }

  onRepoFetch = () => {
    let {dispatch} = this.props;
    let {repos_url} = this.props.userprofile;

    fetch(repos_url)
      .then(res => {
        return res.json()
      })
      .then(res => {
        dispatch({type: 'UPDATE_REPOS', repos: res})
      })
  }

  render() {

    let {userprofile} = this.props;
    let repos = this.props.repos.map((repo, i) => {
      return <li key={i}>{repo.name}</li>
    })
    return (
      <div className="container">
        <h1>Enter a GitHub Username Below</h1>
        <h1>{this.props.username}</h1>

        <input
          type="text"
          onChange={this.onHandleChange}
          value={this.props.user}>
        </input>

        <button
          type="submit"
          className="btn"
          onClick={this.onUserSearch}>
          Search
        </button>

        <h3>{this.props.userprofile.login}</h3>

        <img src={userprofile.avatar_url} alt="" />

        <button
          type="submit"
          className="btn"
          onClick={this.onRepoFetch}>
          Display Repos
        </button>

        {repos}
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return{
    username: state.username,
    userprofile: state.userprofile,
    repos: state.repos
  }
}

export default connect(mapStateToProps)(App);
