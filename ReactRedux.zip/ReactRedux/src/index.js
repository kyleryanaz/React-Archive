import React from "react";
import ReactDOM from "react-dom";
import { connect } from "react-redux";
import { createStore } from "redux";
import { Provider } from "react-redux";

const initialState = {
  count: 0
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case "INCREMENT":
      return { ...state, count: state.count + 1 };
    case "INCREMENT5":
      return { ...state, count: state.count + 5 };
    case "INCREMENT10":
      return { ...state, count: state.count + 10 };
    case "DECREMENT":
      return { ...state, count: state.count - 1 };
    case "DECREMENT5":
      return { ...state, count: state.count - 5 };
    case "DECREMENT10":
      return { ...state, count: state.count - 10 };
    case "RESET":
      return { ...state, count: (state.count = 0) };
    default:
      return state;
  }
};

const mapStateToProps = state => {
  return {
    count: state.count
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onIncrement: () => dispatch({ type: "INCREMENT" }),
    onIncrement5: () => dispatch({ type: "INCREMENT5" }),
    onIncrement10: () => dispatch({ type: "INCREMENT10" }),
    onDecrement: () => dispatch({ type: "DECREMENT" }),
    onDecrement5: () => dispatch({ type: "DECREMENT5" }),
    onDecrement10: () => dispatch({ type: "DECREMENT10" }),
    onReset: () => dispatch({ type: "RESET" })
  };
};

const store = createStore(reducer);

const Counter = ({
  count,
  onIncrement,
  onIncrement5,
  onIncrement10,
  onDecrement,
  onDecrement5,
  onDecrement10,
  onReset
}) => (
  <div>
    <h1>{count}</h1>
    <button onClick={onIncrement10}>+10</button>
    <button onClick={onIncrement5}>+5</button>
    <button onClick={onIncrement}>+</button>
    <button onClick={onReset}>Reset</button>
    <button onClick={onDecrement}>-</button>
    <button onClick={onDecrement5}>-5</button>
    <button onClick={onDecrement10}>-10</button>
  </div>
);

const ConnectedCounter = connect(mapStateToProps, mapDispatchToProps)(Counter);

ReactDOM.render(
  <Provider store={store}>
    <ConnectedCounter />
  </Provider>,
  document.getElementById("root")
);
