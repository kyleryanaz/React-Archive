import React from 'react'
import Things from './things'
import { BrowserRouter as Router, Route, Link } from "react-router-dom";

const FavouriteThings = ({ match }) => (
    <div>
      <h2>Favourite Things</h2>
      <ul>
        <li>
          <Link to={`${match.url}/crown-prince`}>About Crown Prince Mohammad Bin Abdulaziz</Link>
        </li>
        <li>
          <Link to={`${match.url}/red-sea`}>Diving in the Red Sea</Link>
        </li>
        <li>
          <Link to={`${match.url}/bethel-tv`}>Bethel TV</Link>
        </li>
      </ul>

      <Route path={`${match.url}/:thingsId`} component={Things} />
      <Route
        exact
        path={match.url}
        render={() => <h3>Please select a topic.</h3>}
      />
    </div>
);

export default FavouriteThings;